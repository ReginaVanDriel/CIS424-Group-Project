# CIS 424

Development team: Will be working on user stories. To manage this https://trello.com/invite/b/rTV1vNOS/4a38337fae23bd577cc894e655534126/cis424-development
There is a kanban board to help us organize tasks

Our database is setup in a google cloud mysql sever if you want access email me with your public IP address that you will use to test and I will give you access. Other options is to run the flowershop.sql file in a mysql database and it will create a useable database for you. If you go with this route please chagne the DBConnect.cs file in mypos/mypos/ directory

Questions comments concerns:

Feel free to reach out to me by email: jacobmbanghart@gmail.com

discord @: Jqwop#3823

If you see something in this file incorrect please update as necessary.
