﻿using MySqlX.XDevAPI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mypos
{
    public partial class frm_inventory : Form
    {
        private DBConnect db = new DBConnect();
        private int[] inventoryID = new int[0];
        public string[] inventory = { "Toilet Paper", "Toilet Cleaner", "Apples", "Water", "Ramen" };
        public int[] inventoryCount = { 0, 10, 100, 2, 0 };
        public string prevsearch = "!!!!!!!!!!!!!!!!!!!";

        public frm_inventory()
        {
            InitializeComponent();
        }

        public void alerts()
        {
            alertList.Items.Clear();
            for (int j = 0; j < inventoryCount.Length; j++)
            {
                if (inventoryCount[j] == 0)
                    alertList.Items.Add(inventory[j] + " - 0");
            }
        }

        public void search()
        {
            searchList.Items.Clear();
            for (int j = 0; j < inventory.Length; j++)
            {
                if (inventory[j].ToUpper().Contains(prevsearch))
                {
                    searchList.Items.Add(inventory[j] + " - " + inventoryCount[j]);
                }
            }
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            prevsearch = searchBox.Text.ToUpper();
            search();
        }

        private void decreaseBtn_Click(object sender, EventArgs e)
        {
            bool refresh = false;
            error.Visible = false;
            for (int j = 0; j < inventory.Length; j++)
            {
                if (searchList.SelectedItem.ToString().ToUpper().Contains(inventory[j].ToUpper()))
                {
                    if (inventoryCount[j] > 0)
                    {
                        refresh = true;
                        inventoryCount[j]--;
                        db.Update("update inventory set count = "+inventoryCount[j]+" where inventory_id = "+inventoryID[j]+";");
                    }
                    else
                        error.Visible = true;
                }
            }
            if (refresh)
            {
                search();
                alerts();
            }
        }

        private void orderBtn_Click(object sender, EventArgs e)
        {
            error2.Visible = false;
            bool refresh = false;
            int ordernum = 0;
            if (int.TryParse(decreaseBox.Text, out ordernum))
            {
                for (int j = 0; j < inventory.Length; j++)
                {
                    if (alertList.SelectedItem.ToString().ToUpper().Contains(inventory[j].ToUpper()))
                    {
                        inventoryCount[j] += ordernum;
                        refresh = true;
                    }
                }
            }
            else
                error2.Visible = true;

            if (refresh)
            {
                search();
                alerts();
            }
        }

        private void frm_inventory_Load(object sender, EventArgs e)
        {
            List<string>[] results = db.Select("select product_name, count, inventory_id from inventory inner join products on inventory.product_id = products.product_id;", 3);
            inventory = new String[results[0].Count];
            inventoryCount = new int[results[0].Count];
            inventoryID = new int[results[0].Count];
            for(int i = 0; i < results[0].Count; i++)
            {
                inventory[i] = results[0][i];
                inventoryCount[i] = Convert.ToInt32(results[1][i]);
                inventoryID[i] = Convert.ToInt32(results[2][i]);
            }
            prevsearch = searchBox.Text.ToUpper();
            search();
            alerts();
        }
    }
}
