﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mypos
{
    public partial class frm_cashier : Form
    {

        private DBConnect db = new DBConnect();

        public frm_cashier()
        {
            InitializeComponent();
        }

        private void frm_cashier_Load(object sender, EventArgs e)
        {

        }

        private void txt_barcode_TextChanged(object sender, EventArgs e)
        {
            //DataTable scannedItem = new DataTable();
            List<string>[] scannedItem = db.Select("SELECT * FROM products WHERE product_code = '" + txt_productCode.Text + "';",3);
            if (scannedItem.Length > 0)
            {
            //
            //
            //
            //
                txt_productCode.Clear();
                txt_productCode.Select();
                calculate_money();


            }
        }

        private void calculate_money()
        {
            double subtotal = 0;
            double total = 0;
            double tax = 0;

            int i;
            for (i = 0; i <= dgvCheckout.Rows.Count - 1; i++)
            {
                subtotal += Convert.ToDouble(dgvCheckout.Rows[i].Cells[4].Value);
            }

            txt_subtotal.Text = subtotal.ToString("##,##0.00");
            tax = subtotal * 0.06;
            txt_tax.Text = tax.ToString("##,##0.00");
            total = tax + subtotal;
            txt_totalAmount.Text = total.ToString("##,##0.00");
        }

        private void btn_removeProduct_Click(object sender, EventArgs e)
        {
            if (dgvCheckout.Rows.Count > 0)
            {
                dgvCheckout.Rows.Remove(dgvCheckout.CurrentRow);
                calculate_money();
                calculate_change();
            }
            else
            {
                MessageBox.Show("There is no selected item", "Warning");
            }
        }

        private void calculate_change()
        {
            if (txt_charge.Text == "")
            {
                txt_change.Text = "";
                return;
            }
            if (dgvCheckout.Rows.Count > 0)
            {
                Double charge = Convert.ToDouble(txt_charge.Text);
                Double change = charge - Convert.ToDouble(txt_totalAmount.Text);
                txt_change.Text = change.ToString("##,##00.00");
                if (charge >= Convert.ToDouble(txt_totalAmount.Text))
                {
                    btn_checkout.Enabled = true;
                    btn_checkout.BackColor = Color.Green;
                }
                else
                {
                    btn_checkout.Enabled = false;
                    btn_checkout.BackColor = Color.Gray;
                }
;
            }
            else
            {
                txt_change.Clear();
                txt_charge.Clear();
            }
        }

        private void txt_charge_TextChanged(object sender, EventArgs e)
        {
            if (txt_charge.Text == "")
            {
                txt_change.Text = "";
                return;
            }
            if (dgvCheckout.Rows.Count > 0)
            {
                Double charge = Convert.ToDouble(txt_charge.Text);
                Double change = charge - Convert.ToDouble(txt_totalAmount.Text);
                txt_change.Text = change.ToString("##,##00.00");
                if (charge >= Convert.ToDouble(txt_totalAmount.Text))
                {
                    btn_checkout.Enabled = true;
                    btn_checkout.BackColor = Color.Green;
                }
                else
                {
                    btn_checkout.Enabled = false;
                    btn_checkout.BackColor = Color.Gray;
                }
;
            }
            else
            {
                MessageBox.Show("Please Select an Item Before entering the charge", "Warning");
                txt_charge.Clear();
            }
        }

        private void clear_all_data()
        {
            txt_productCode.Clear();
            txt_qty.Text = "1";
            dgvCheckout.Rows.Clear();
            dgvCheckout.Refresh();
            txt_subtotal.Clear();
            txt_tax.Clear();
            txt_totalAmount.Clear();
            txt_charge.Clear();
            txt_change.Clear();
            txt_productCode.Select();
        }

        private void btn_checkout_Click(object sender, EventArgs e)
        {

        }
    }
}
