﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mypos
{
    public partial class frm_main : Form
    {
        public frm_main()
        {
            InitializeComponent();
        }

        private void fsmInventory_Click(object sender, EventArgs e)
        {
            frm_inventory inventoryForm = new frm_inventory() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true, FormBorderStyle = FormBorderStyle.None };
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(inventoryForm);
            inventoryForm.Show();
        }

        private void fsmRewards_Click(object sender, EventArgs e)
        {
            frm_customer_rewards customerForm = new frm_customer_rewards() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true, FormBorderStyle = FormBorderStyle.None };
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(customerForm);
            customerForm.Show();
        }

        private void cashierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm_cashier cashierForm = new frm_cashier() { Dock = DockStyle.Fill, TopLevel = false, TopMost = true, FormBorderStyle = FormBorderStyle.None };
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(cashierForm);
            cashierForm.Show();
        }
    }
}
