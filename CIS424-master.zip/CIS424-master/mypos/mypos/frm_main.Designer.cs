﻿namespace mypos
{
    partial class frm_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fsmLogin = new System.Windows.Forms.ToolStripMenuItem();
            this.dataManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fsmInventory = new System.Windows.Forms.ToolStripMenuItem();
            this.fsmRewards = new System.Windows.Forms.ToolStripMenuItem();
            this.fsmCashier = new System.Windows.Forms.ToolStripMenuItem();
            this.managerFunctionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fsmConsumerReport = new System.Windows.Forms.ToolStripMenuItem();
            this.fsmEmployeeReport = new System.Windows.Forms.ToolStripMenuItem();
            this.fsmSalesReport = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlMain = new System.Windows.Forms.Panel();
            this.cashierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fsmLogin,
            this.dataManagementToolStripMenuItem,
            this.cashierToolStripMenuItem,
            this.fsmCashier,
            this.managerFunctionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1400, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fsmLogin
            // 
            this.fsmLogin.Name = "fsmLogin";
            this.fsmLogin.Size = new System.Drawing.Size(80, 24);
            this.fsmLogin.Text = "Login As";
            // 
            // dataManagementToolStripMenuItem
            // 
            this.dataManagementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fsmInventory,
            this.fsmRewards});
            this.dataManagementToolStripMenuItem.Name = "dataManagementToolStripMenuItem";
            this.dataManagementToolStripMenuItem.Size = new System.Drawing.Size(147, 24);
            this.dataManagementToolStripMenuItem.Text = "Data Management";
            // 
            // fsmInventory
            // 
            this.fsmInventory.Name = "fsmInventory";
            this.fsmInventory.Size = new System.Drawing.Size(224, 26);
            this.fsmInventory.Text = "Inventory";
            this.fsmInventory.Click += new System.EventHandler(this.fsmInventory_Click);
            // 
            // fsmRewards
            // 
            this.fsmRewards.Name = "fsmRewards";
            this.fsmRewards.Size = new System.Drawing.Size(224, 26);
            this.fsmRewards.Text = "Customer Rewards";
            this.fsmRewards.Click += new System.EventHandler(this.fsmRewards_Click);
            // 
            // fsmCashier
            // 
            this.fsmCashier.Name = "fsmCashier";
            this.fsmCashier.Size = new System.Drawing.Size(14, 24);
            // 
            // managerFunctionsToolStripMenuItem
            // 
            this.managerFunctionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fsmConsumerReport,
            this.fsmEmployeeReport,
            this.fsmSalesReport});
            this.managerFunctionsToolStripMenuItem.Name = "managerFunctionsToolStripMenuItem";
            this.managerFunctionsToolStripMenuItem.Size = new System.Drawing.Size(148, 24);
            this.managerFunctionsToolStripMenuItem.Text = "Manager Functions";
            // 
            // fsmConsumerReport
            // 
            this.fsmConsumerReport.Name = "fsmConsumerReport";
            this.fsmConsumerReport.Size = new System.Drawing.Size(213, 26);
            this.fsmConsumerReport.Text = "Customer Reports";
            // 
            // fsmEmployeeReport
            // 
            this.fsmEmployeeReport.Name = "fsmEmployeeReport";
            this.fsmEmployeeReport.Size = new System.Drawing.Size(213, 26);
            this.fsmEmployeeReport.Text = "Employee Reports";
            // 
            // fsmSalesReport
            // 
            this.fsmSalesReport.Name = "fsmSalesReport";
            this.fsmSalesReport.Size = new System.Drawing.Size(213, 26);
            this.fsmSalesReport.Text = "Sales Reports";
            // 
            // pnlMain
            // 
            this.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMain.Location = new System.Drawing.Point(0, 28);
            this.pnlMain.Margin = new System.Windows.Forms.Padding(4);
            this.pnlMain.Name = "pnlMain";
            this.pnlMain.Size = new System.Drawing.Size(1400, 703);
            this.pnlMain.TabIndex = 1;
            // 
            // cashierToolStripMenuItem
            // 
            this.cashierToolStripMenuItem.Name = "cashierToolStripMenuItem";
            this.cashierToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.cashierToolStripMenuItem.Text = "Cashier";
            this.cashierToolStripMenuItem.Click += new System.EventHandler(this.cashierToolStripMenuItem_Click);
            // 
            // frm_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1400, 731);
            this.Controls.Add(this.pnlMain);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frm_main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frm_main";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fsmLogin;
        private System.Windows.Forms.ToolStripMenuItem dataManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fsmInventory;
        private System.Windows.Forms.ToolStripMenuItem fsmCashier;
        private System.Windows.Forms.ToolStripMenuItem fsmRewards;
        private System.Windows.Forms.ToolStripMenuItem managerFunctionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fsmConsumerReport;
        private System.Windows.Forms.ToolStripMenuItem fsmEmployeeReport;
        private System.Windows.Forms.ToolStripMenuItem fsmSalesReport;
        private System.Windows.Forms.Panel pnlMain;
        private System.Windows.Forms.ToolStripMenuItem cashierToolStripMenuItem;
    }
}