﻿using System;

namespace mypos
{
    partial class frm_cashier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_productCode = new System.Windows.Forms.TextBox();
            this.txt_qty = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dgvCheckout = new System.Windows.Forms.DataGridView();
            this.clBarcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clProduct = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clTotalPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_removeProduct = new System.Windows.Forms.Button();
            this.txt_subtotal = new System.Windows.Forms.TextBox();
            this.txt_tax = new System.Windows.Forms.TextBox();
            this.txt_totalAmount = new System.Windows.Forms.TextBox();
            this.txt_charge = new System.Windows.Forms.TextBox();
            this.txt_change = new System.Windows.Forms.TextBox();
            this.Subtotal = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_checkout = new System.Windows.Forms.Button();
            this.label_staff = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_reward_points = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_customer_email = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCheckout)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_productCode
            // 
            this.txt_productCode.Location = new System.Drawing.Point(120, 34);
            this.txt_productCode.Margin = new System.Windows.Forms.Padding(4);
            this.txt_productCode.Name = "txt_productCode";
            this.txt_productCode.Size = new System.Drawing.Size(182, 22);
            this.txt_productCode.TabIndex = 0;
            this.txt_productCode.TextChanged += new System.EventHandler(this.txt_barcode_TextChanged);
            // 
            // txt_qty
            // 
            this.txt_qty.Location = new System.Drawing.Point(120, 87);
            this.txt_qty.Margin = new System.Windows.Forms.Padding(4);
            this.txt_qty.Name = "txt_qty";
            this.txt_qty.Size = new System.Drawing.Size(182, 22);
            this.txt_qty.TabIndex = 1;
            this.txt_qty.Text = "1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Product Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(46, 92);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Quantity";
            // 
            // dgvCheckout
            // 
            this.dgvCheckout.AllowUserToAddRows = false;
            this.dgvCheckout.AllowUserToDeleteRows = false;
            this.dgvCheckout.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCheckout.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clBarcode,
            this.clProduct,
            this.clPrice,
            this.clQuantity,
            this.clTotalPrice});
            this.dgvCheckout.Location = new System.Drawing.Point(32, 159);
            this.dgvCheckout.Margin = new System.Windows.Forms.Padding(4);
            this.dgvCheckout.Name = "dgvCheckout";
            this.dgvCheckout.ReadOnly = true;
            this.dgvCheckout.RowHeadersWidth = 51;
            this.dgvCheckout.Size = new System.Drawing.Size(680, 308);
            this.dgvCheckout.TabIndex = 4;
            // 
            // clBarcode
            // 
            this.clBarcode.HeaderText = "Barcode";
            this.clBarcode.MinimumWidth = 6;
            this.clBarcode.Name = "clBarcode";
            this.clBarcode.ReadOnly = true;
            this.clBarcode.Width = 125;
            // 
            // clProduct
            // 
            this.clProduct.HeaderText = "Product";
            this.clProduct.MinimumWidth = 6;
            this.clProduct.Name = "clProduct";
            this.clProduct.ReadOnly = true;
            this.clProduct.Width = 125;
            // 
            // clPrice
            // 
            this.clPrice.HeaderText = "Price";
            this.clPrice.MinimumWidth = 6;
            this.clPrice.Name = "clPrice";
            this.clPrice.ReadOnly = true;
            this.clPrice.Width = 125;
            // 
            // clQuantity
            // 
            this.clQuantity.HeaderText = "Quantity";
            this.clQuantity.MinimumWidth = 6;
            this.clQuantity.Name = "clQuantity";
            this.clQuantity.ReadOnly = true;
            this.clQuantity.Width = 125;
            // 
            // clTotalPrice
            // 
            this.clTotalPrice.HeaderText = "TotalPrice";
            this.clTotalPrice.MinimumWidth = 6;
            this.clTotalPrice.Name = "clTotalPrice";
            this.clTotalPrice.ReadOnly = true;
            this.clTotalPrice.Width = 125;
            // 
            // btn_removeProduct
            // 
            this.btn_removeProduct.Location = new System.Drawing.Point(186, 493);
            this.btn_removeProduct.Margin = new System.Windows.Forms.Padding(4);
            this.btn_removeProduct.Name = "btn_removeProduct";
            this.btn_removeProduct.Size = new System.Drawing.Size(384, 28);
            this.btn_removeProduct.TabIndex = 5;
            this.btn_removeProduct.Text = "Remove";
            this.btn_removeProduct.UseVisualStyleBackColor = true;
            this.btn_removeProduct.Click += new System.EventHandler(this.btn_removeProduct_Click);
            // 
            // txt_subtotal
            // 
            this.txt_subtotal.Enabled = false;
            this.txt_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_subtotal.Location = new System.Drawing.Point(902, 168);
            this.txt_subtotal.Margin = new System.Windows.Forms.Padding(4);
            this.txt_subtotal.Name = "txt_subtotal";
            this.txt_subtotal.Size = new System.Drawing.Size(204, 37);
            this.txt_subtotal.TabIndex = 6;
            // 
            // txt_tax
            // 
            this.txt_tax.Enabled = false;
            this.txt_tax.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_tax.Location = new System.Drawing.Point(902, 229);
            this.txt_tax.Margin = new System.Windows.Forms.Padding(4);
            this.txt_tax.Name = "txt_tax";
            this.txt_tax.Size = new System.Drawing.Size(204, 37);
            this.txt_tax.TabIndex = 7;
            // 
            // txt_totalAmount
            // 
            this.txt_totalAmount.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.txt_totalAmount.Enabled = false;
            this.txt_totalAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_totalAmount.ForeColor = System.Drawing.SystemColors.Window;
            this.txt_totalAmount.Location = new System.Drawing.Point(902, 283);
            this.txt_totalAmount.Margin = new System.Windows.Forms.Padding(4);
            this.txt_totalAmount.Name = "txt_totalAmount";
            this.txt_totalAmount.Size = new System.Drawing.Size(204, 37);
            this.txt_totalAmount.TabIndex = 8;
            // 
            // txt_charge
            // 
            this.txt_charge.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_charge.Location = new System.Drawing.Point(902, 332);
            this.txt_charge.Margin = new System.Windows.Forms.Padding(4);
            this.txt_charge.Name = "txt_charge";
            this.txt_charge.Size = new System.Drawing.Size(204, 37);
            this.txt_charge.TabIndex = 9;
            this.txt_charge.TextChanged += new System.EventHandler(this.txt_charge_TextChanged);
            // 
            // txt_change
            // 
            this.txt_change.Enabled = false;
            this.txt_change.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_change.Location = new System.Drawing.Point(902, 379);
            this.txt_change.Margin = new System.Windows.Forms.Padding(4);
            this.txt_change.Name = "txt_change";
            this.txt_change.Size = new System.Drawing.Size(204, 37);
            this.txt_change.TabIndex = 10;
            // 
            // Subtotal
            // 
            this.Subtotal.AutoSize = true;
            this.Subtotal.Location = new System.Drawing.Point(821, 188);
            this.Subtotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Subtotal.Name = "Subtotal";
            this.Subtotal.Size = new System.Drawing.Size(60, 17);
            this.Subtotal.TabIndex = 11;
            this.Subtotal.Text = "Subtotal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(826, 249);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Tax 6%";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(789, 303);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 17);
            this.label5.TabIndex = 13;
            this.label5.Text = "Amount Total";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(831, 347);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Charge";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(133, 28);
            this.label7.TabIndex = 18;
            // 
            // btn_checkout
            // 
            this.btn_checkout.BackColor = System.Drawing.Color.Gray;
            this.btn_checkout.Enabled = false;
            this.btn_checkout.Location = new System.Drawing.Point(813, 493);
            this.btn_checkout.Margin = new System.Windows.Forms.Padding(4);
            this.btn_checkout.Name = "btn_checkout";
            this.btn_checkout.Size = new System.Drawing.Size(304, 54);
            this.btn_checkout.TabIndex = 16;
            this.btn_checkout.Text = "Check Out";
            this.btn_checkout.UseVisualStyleBackColor = false;
            this.btn_checkout.Click += new System.EventHandler(this.btn_checkout_Click);
            // 
            // label_staff
            // 
            this.label_staff.AutoSize = true;
            this.label_staff.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_staff.Location = new System.Drawing.Point(1117, 54);
            this.label_staff.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_staff.Name = "label_staff";
            this.label_staff.Size = new System.Drawing.Size(0, 42);
            this.label_staff.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 23);
            this.label3.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(798, 399);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "Change Due";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(736, 450);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(149, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "Reward Points Earned";
            // 
            // txt_reward_points
            // 
            this.txt_reward_points.Enabled = false;
            this.txt_reward_points.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_reward_points.Location = new System.Drawing.Point(902, 430);
            this.txt_reward_points.Margin = new System.Windows.Forms.Padding(4);
            this.txt_reward_points.Name = "txt_reward_points";
            this.txt_reward_points.Size = new System.Drawing.Size(204, 37);
            this.txt_reward_points.TabIndex = 21;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(416, 37);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 17);
            this.label10.TabIndex = 23;
            this.label10.Text = "Customer Email";
            // 
            // txt_customer_email
            // 
            this.txt_customer_email.Location = new System.Drawing.Point(530, 34);
            this.txt_customer_email.Margin = new System.Windows.Forms.Padding(4);
            this.txt_customer_email.Name = "txt_customer_email";
            this.txt_customer_email.Size = new System.Drawing.Size(182, 22);
            this.txt_customer_email.TabIndex = 22;
            // 
            // frm_cashier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1142, 573);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txt_customer_email);
            this.Controls.Add(this.txt_reward_points);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label_staff);
            this.Controls.Add(this.btn_checkout);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Subtotal);
            this.Controls.Add(this.txt_change);
            this.Controls.Add(this.txt_charge);
            this.Controls.Add(this.txt_totalAmount);
            this.Controls.Add(this.txt_tax);
            this.Controls.Add(this.txt_subtotal);
            this.Controls.Add(this.btn_removeProduct);
            this.Controls.Add(this.dgvCheckout);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_qty);
            this.Controls.Add(this.txt_productCode);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frm_cashier";
            this.Text = "Cashier";
            this.Load += new System.EventHandler(this.frm_cashier_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCheckout)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_productCode;
        private System.Windows.Forms.TextBox txt_qty;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dgvCheckout;
        private System.Windows.Forms.Button btn_removeProduct;
        private System.Windows.Forms.TextBox txt_subtotal;
        private System.Windows.Forms.TextBox txt_tax;
        private System.Windows.Forms.TextBox txt_totalAmount;
        private System.Windows.Forms.TextBox txt_charge;
        private System.Windows.Forms.TextBox txt_change;
        private System.Windows.Forms.Label Subtotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btn_checkout;
        private System.Windows.Forms.DataGridViewTextBoxColumn clBarcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn clProduct;
        private System.Windows.Forms.DataGridViewTextBoxColumn clPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn clQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn clTotalPrice;
        private System.Windows.Forms.Label label_staff;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_reward_points;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_customer_email;
    }
}