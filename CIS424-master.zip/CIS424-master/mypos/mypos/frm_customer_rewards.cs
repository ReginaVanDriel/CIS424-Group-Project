﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace mypos
{
    public partial class frm_customer_rewards : Form
    {
        private DBConnect db = new DBConnect();
        public frm_customer_rewards()
        {
            InitializeComponent();
        }

        private void load_custAccount()
        {
            //dgvCustomer.DataSource = this.myDatabase.executeSqlCommand("SELECT * FROM  customers AND addresses");
            List<string>[] results = db.Select("SELECT * from customer_info", 11);
            List<string>[] customers = results;
            dgvCustomer.ColumnCount = customers.Length;
            dgvCustomer.Columns[0].Name = "Customer ID";
            dgvCustomer.Columns[1].Name = "First Name";
            dgvCustomer.Columns[2].Name = "Last Name";
            dgvCustomer.Columns[3].Name = "Email";
            dgvCustomer.Columns[4].Name = "Shipping Address Line 1";
            dgvCustomer.Columns[5].Name = "Shipping Address Line 2";
            dgvCustomer.Columns[6].Name = "Shipping Address City";
            dgvCustomer.Columns[7].Name = "Shipping Address Sate";
            dgvCustomer.Columns[8].Name = "Shipping Address Zip Code";
            dgvCustomer.Columns[9].Name = "Phone Number";
            dgvCustomer.Columns[10].Name = "Rewards points";
            //dgvCustomer.ColumnCount = customers.Count;
            dgvCustomer.Rows.Clear();
            for (int i = 0; i < customers[0].Count; i++)
            {
                string[] row = { customers[0][i], customers[1][i], customers[2][i], customers[3][i], customers[4][i], customers[5][i], customers[6][i], customers[7][i], customers[8][i], customers[9][i], customers[10][i] };
                dgvCustomer.Rows.Add(row);
            }
        }
        private void Frm_cust_rewards_Load(object sender, EventArgs e)
        {
            load_custAccount();
        }

        private void dgvCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            lblCustomerID.Text = dgvCustomer.CurrentRow.Cells[0].Value.ToString();
            txt_firstname.Text = dgvCustomer.CurrentRow.Cells[1].Value.ToString();
            txt_lastname.Text = dgvCustomer.CurrentRow.Cells[2].Value.ToString();
            txt_email.Text = dgvCustomer.CurrentRow.Cells[3].Value.ToString();
            txtShippingLine1.Text = dgvCustomer.CurrentRow.Cells[4].Value.ToString();
            txtShippingLine2.Text = dgvCustomer.CurrentRow.Cells[5].Value.ToString();
            txtShippingCity.Text = dgvCustomer.CurrentRow.Cells[6].Value.ToString();
            txtShippingState.Text = dgvCustomer.CurrentRow.Cells[7].Value.ToString();
            txtShippingZip.Text = dgvCustomer.CurrentRow.Cells[8].Value.ToString();
            txtShippingPhone.Text = dgvCustomer.CurrentRow.Cells[9].Value.ToString();
            txt_rewards.Text = dgvCustomer.CurrentRow.Cells[10].Value.ToString();
        }

        private void btn_addCustomer_Click(object sender, EventArgs e)
        {
            if (txt_firstname.Text == "")
            {
                MessageBox.Show("Please Enter First Name.", "Warning");
                return;
            }
            if (txt_lastname.Text == "")
            {
                MessageBox.Show("Please Enter Last Name.", "Warning");
                return;
            }
            if (txt_email.Text == "")
            {
                MessageBox.Show("Please Enter Email.", "Warning");
                return;
            }

            List<string>[] checkCustomer = db.Select("select * from customer_info where email = " + txt_email.Text + ";", 7);

            if (checkCustomer.Length > 0)
            {
                MessageBox.Show("This customer is already entered in the system.", "Warning");
            }
            else
            {
                //Insert data into database
                db.Insert("start transaction;insert into customers(email_address, password, first_name, last_name, rewards_points) values('"+txt_email.Text+"', '', '"+txt_firstname.Text+"', '"+txt_lastname.Text+"', "+Convert.ToInt32(txt_rewards.Text)+ ");insert into addresses(customer_id, line1, line2, city, state, zip_code, phone, disabled) values(last_insert_id(), '"+txtShippingLine1.Text+"', '"+txtShippingLine2.Text+"', '"+txtShippingCity.Text+"', '"+txtShippingState.Text+"', '"+txtShippingZip.Text+"', '"+txtShippingPhone.Text+"', 0); update customers set shipping_address_id = last_insert_id() where email_address = '" + txt_email.Text+"';commit;");
                MessageBox.Show("The customer has been saved.", "Complete");
                load_custAccount();
            }

        }

        private void btn_updateCustomer_Click(object sender, EventArgs e)
        {
            if (lblCustomerID.Text == "")
            {
                MessageBox.Show("Please Select a Customer.", "Warning");
            }
            else
            {
                // update user information
                db.Update("start transaction;update customers set email_address = '" + txt_email.Text + "', first_name = '" + txt_firstname.Text + "', last_name = '" + txt_lastname.Text + "', rewards_points = " + Convert.ToInt32(txt_rewards.Text) + " where email_address = '" + txt_email.Text + "'; update addresses set line1 = '" +txtShippingLine1.Text+ "', line2 = '" + txtShippingLine2.Text + "', city = '" + txtShippingCity.Text + "', state = '" + txtShippingState.Text + "', zip_code = '" + txtShippingZip.Text + "', phone = '"+txtShippingPhone.Text+"' where customer_id = '"+ lblCustomerID.Text + "';commit;");
                MessageBox.Show("The customer has been updated.", "Complete");
                load_custAccount();
            }
        }
    }
}
