﻿namespace mypos
{
    partial class frm_inventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.orderBtn = new System.Windows.Forms.Button();
            this.decreaseBox = new System.Windows.Forms.TextBox();
            this.alertList = new System.Windows.Forms.CheckedListBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.decreaseBtn = new System.Windows.Forms.Button();
            this.searchList = new System.Windows.Forms.CheckedListBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.error = new System.Windows.Forms.Label();
            this.error2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.orderBtn);
            this.groupBox1.Controls.Add(this.decreaseBox);
            this.groupBox1.Controls.Add(this.alertList);
            this.groupBox1.Location = new System.Drawing.Point(328, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(216, 316);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inventory Alerts";
            // 
            // orderBtn
            // 
            this.orderBtn.Location = new System.Drawing.Point(135, 284);
            this.orderBtn.Name = "orderBtn";
            this.orderBtn.Size = new System.Drawing.Size(75, 23);
            this.orderBtn.TabIndex = 3;
            this.orderBtn.Text = "Order";
            this.orderBtn.UseVisualStyleBackColor = true;
            this.orderBtn.Click += new System.EventHandler(this.orderBtn_Click);
            // 
            // decreaseBox
            // 
            this.decreaseBox.Location = new System.Drawing.Point(6, 284);
            this.decreaseBox.Name = "decreaseBox";
            this.decreaseBox.Size = new System.Drawing.Size(123, 20);
            this.decreaseBox.TabIndex = 4;
            // 
            // alertList
            // 
            this.alertList.FormattingEnabled = true;
            this.alertList.Location = new System.Drawing.Point(6, 19);
            this.alertList.Name = "alertList";
            this.alertList.Size = new System.Drawing.Size(204, 259);
            this.alertList.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.decreaseBtn);
            this.groupBox2.Controls.Add(this.searchList);
            this.groupBox2.Controls.Add(this.searchBtn);
            this.groupBox2.Controls.Add(this.searchBox);
            this.groupBox2.Location = new System.Drawing.Point(22, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(279, 315);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Inventory Search";
            // 
            // decreaseBtn
            // 
            this.decreaseBtn.Location = new System.Drawing.Point(100, 280);
            this.decreaseBtn.Name = "decreaseBtn";
            this.decreaseBtn.Size = new System.Drawing.Size(75, 23);
            this.decreaseBtn.TabIndex = 2;
            this.decreaseBtn.Text = "Decrease";
            this.decreaseBtn.UseVisualStyleBackColor = true;
            this.decreaseBtn.Click += new System.EventHandler(this.decreaseBtn_Click);
            // 
            // searchList
            // 
            this.searchList.FormattingEnabled = true;
            this.searchList.Location = new System.Drawing.Point(6, 45);
            this.searchList.Name = "searchList";
            this.searchList.Size = new System.Drawing.Size(267, 229);
            this.searchList.TabIndex = 2;
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(181, 17);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(92, 23);
            this.searchBtn.TabIndex = 1;
            this.searchBtn.Text = "Search";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(6, 19);
            this.searchBox.Name = "searchBox";
            this.searchBox.Size = new System.Drawing.Size(169, 20);
            this.searchBox.TabIndex = 0;
            // 
            // error
            // 
            this.error.AutoSize = true;
            this.error.ForeColor = System.Drawing.Color.Red;
            this.error.Location = new System.Drawing.Point(95, 341);
            this.error.Name = "error";
            this.error.Size = new System.Drawing.Size(135, 13);
            this.error.TabIndex = 2;
            this.error.Text = "Error - Selected Item Empty";
            this.error.Visible = false;
            // 
            // error2
            // 
            this.error2.AutoSize = true;
            this.error2.ForeColor = System.Drawing.Color.Red;
            this.error2.Location = new System.Drawing.Point(376, 341);
            this.error2.Name = "error2";
            this.error2.Size = new System.Drawing.Size(116, 13);
            this.error2.TabIndex = 3;
            this.error2.Text = "Error - Invalid Selection";
            this.error2.Visible = false;
            // 
            // frm_inventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 394);
            this.Controls.Add(this.error2);
            this.Controls.Add(this.error);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "frm_inventory";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frm_inventory_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button orderBtn;
        private System.Windows.Forms.TextBox decreaseBox;
        private System.Windows.Forms.CheckedListBox alertList;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button decreaseBtn;
        private System.Windows.Forms.CheckedListBox searchList;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.TextBox searchBox;
        private System.Windows.Forms.Label error;
        private System.Windows.Forms.Label error2;
    }
}