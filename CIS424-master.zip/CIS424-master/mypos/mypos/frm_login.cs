﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace mypos
{
    public partial class frm_login : Form
    {
        //private mydatabase myDatabase = new mydatabase();
        public frm_login()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            DataTable loginTable = new DataTable();
            //loginTable = this.myDatabase.executeSqlCommand("SELECT * FROM tbl_userAccount WHERE username='" + txt_username.Text + "' AND password='" + txt_password.Text + "' ");
            if (loginTable.Rows.Count > 0)
            {
                MessageBox.Show("You logged in");
                // call frm_main
                frm_main frm_Main = new frm_main();
                //frm_Main.userLogin = loginTable;
                frm_Main.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Username and Password are incorrect!");
            }
        }
    }
}
